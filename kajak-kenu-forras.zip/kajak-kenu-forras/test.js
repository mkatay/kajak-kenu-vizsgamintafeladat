class TestSuite {
    constructor() {
        this.msgArr = [];
        this.ol = document.createElement('ol');
        document.querySelector('body').appendChild(document.createElement('hr'))
        document.querySelector('body').appendChild(this.ol);
    }

    assert(condition, message) {
        const resultMessage = condition
            ? `${message} ✅`
            : `${message} ❌`;
        this.msgArr.push(resultMessage);
       // console.log(this.msgArr);
    }

    showResults() {
        this.msgArr.forEach((msg) => {
            const li = document.createElement('li');
            li.textContent = `teszt: ${msg}`;
            this.ol.appendChild(li);
        });
    }

    runTests() {
        this.runBannerTest();
        this.runTitleTest();
        this.runMenuTest();
        this.runSectionTest()
        this.runCardTest()
        this.runImgTest()
        this.runH4Test()
        this.showResults();
    }

    runBannerTest() {
        const banner = document.querySelector('.banner');
        const bannerStyle=window.getComputedStyle(banner)
        this.assert(bannerStyle.height=='300px', 'A banner osztályjelölővel ellátott HTML elem magassága 300px?');
        console.log(bannerStyle.backgroundImage)
       
        if(bannerStyle.backgroundImage!='none'){
            this.assert(bannerStyle.backgroundImage.match('banner.jpg'),'háttérképe: banner.jpg')
            this.assert(bannerStyle.backgroundPosition=='50% 50%','A háttérkép középre van helyezve vízszintesen is és függőlegesen is.')
        }else{
             this.assert(bannerStyle.backgroundImage!='none','a banner osztályjelölővel ellátott HTML elemnek van háttérképe?')
             this.assert(false,'háttérképe: banner.jpg')
             this.assert(false,'A háttérkép középre van helyezve vízszintesen is és függőlegesen is.')
        }
        
        
    }
    runTitleTest() {
        const i = document.querySelector('h1>i');     
        if(i){
            const iStyle=window.getComputedStyle(i)
            this.assert(iStyle.fontSize==`${16*0.8}px`,' Betűmérete a böngésző alapértelmezett betűméretének 80%-a.')
        }else{
             this.assert(i,'A főcímben szereplő név legyen dőlt betűs.')
             this.assert(false,' Betűmérete a böngésző alapértelmezett betűméretének 80%-a.')
        }
        const h1=document.querySelector('h1');
        this.assert(h1.classList.contains('text-white'),'A főcím betű színe le van cserélve fehérre, Bootstrap osztályjelölőt használva.')
    }
    runMenuTest(){
        const aTags=document.querySelectorAll('ul>li a')
        console.log(aTags.length);
        this.assert(aTags.length==5,'A weboldalak menüjét egészítse ki egy új  menüponttal.')
        if(aTags.length==5){
            this.assert(aTags[4].textContent=='Történelem','A weboldalak menüje ki van egészítse ki egy új „Történelem” menüponttal, ')
            this.assert(aTags[4].href=='https://tortenelem.kajakkenusport.hu/','...amely https://tortenelem.kajakkenusport.hu/ oldalra mutat!')
            this.assert(aTags[4].target=='_blank','...új oldalon nyílik meg')
        }
    }

    runSectionTest(){
        const cols=document.querySelectorAll('#mult>.row div')
        console.log(cols.length);
        this.assert(cols[0].classList.contains('col-md-3') && 
            cols[1].classList.contains('col-md-6') && 
            cols[2].classList.contains('col-md-3'),
            'A mult azonosítójú section elemben található 3 oszlop elrendezése: a középső oszlopban levő szöveg 2-szer annyi helyet foglal el medium töréspontnál mint a jobb és bal széleken levő fotók.')
    }
    runCardTest(){
        const cols=document.querySelectorAll('#buszke .col-12')
        console.log(cols.length);
        Array.from(cols).forEach((obj,i)=>{
            this.assert(obj.classList.contains('col-md-6'),`A/az ${i+1}. kártyákat tartalmazó oszlop a buszke azonosítójú section elemben, a közepes eszközöktől felfele 2 oszlopos elrendezésben jelenik meg.`)
        })
    }
    runImgTest(){
        const img=document.querySelector('#bajnokok img')
        this.assert(img.classList.contains('img-fluid'),'A bajnokok azonosítójú section elemben található kép reszponzív.')
    }
    runH4Test(){
        const h4=document.querySelector('h4');
        const h4Style=window.getComputedStyle(h4);
        console.log(h4Style.borderBottom);
        this.assert(h4Style.borderBottom=='3px dotted rgb(0, 0, 0)','Az alcím alján 3 pixel vastag pontozott stílusú szegély van.')
        this.assert(h4Style.fontVariant=='small-caps','Az alcím kiskapitális stílusú.')
    }

}
const testSuite = new TestSuite();
testSuite.runTests();
